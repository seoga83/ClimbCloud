﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using PlayFab;
using PlayFab.ClientModels;
using UnityEngine.SceneManagement;

public class LobbyMgr : MonoBehaviour
{
    public Image FadePanel;
    Color FadeColor;
    bool isFadeIn = true;
    bool isFadeOut = false;
    float FadeTime = 1.0f;
    float TimeTic;

    bool isStartBtn = false;

    public GameObject RankPanel;

    public Text MyCoin_Txt = null;
    public Text Ranking_Text = null;

    public Button m_GameStartBtn = null;
    public Button m_LogOutBtn = null;

    int m_My_Rank = 0;

    float RestoreTimer = 0.0f;

    float ShowMsTimer = 0.0f;

    float DelayGetLB = 3.0f;

    // Start is called before the first frame update
    void Start()
    {
        TimeTic = FadeTime;

        Ranking_Text.text = "";

        if (m_GameStartBtn != null)
            m_GameStartBtn.onClick.AddListener(() =>
            {
                isFadeOut = true;
                isStartBtn = true;
                FadePanel.gameObject.SetActive(true);
                //UnityEngine.SceneManagement.SceneManager.LoadScene("GameScene");
            });

        if (m_LogOutBtn != null)
            m_LogOutBtn.onClick.AddListener(() =>
            {
                GlobalValue.g_Unique_ID = "";
                GlobalValue.g_NickName = "";
                GlobalValue.g_BestCoin = 0;
                PlayFabClientAPI.ForgetAllCredentials(); //Playfab -> LogOut
                isFadeOut = true;
                FadePanel.gameObject.SetActive(true);
                //SceneManager.LoadScene("Title");
            });

        //<---자동 리셋인 경우
        RestoreTimer = 10.0f; //<---자동 리셋 //초기 딜레이 = 3.0f + 7.0f;
        //<---자동 리셋인 경우

        RefreshMyInfo(); //우선 셋팅해 놓고 내 등수 불러온 후 다시 갱신

        GetLeaderboard();
        DelayGetLB = 3.0f;  //3.0f초 뒤에 리더보드 한번 더 로딩하기..
    }//void Start()

    // Update is called once per frame
    void Update()
    {
        if(RankPanel.transform.localPosition.x > 0 && !isFadeIn)
            RankPanel.transform.localPosition = new Vector3(RankPanel.transform.localPosition.x - 5,
                    RankPanel.transform.localPosition.y, RankPanel.transform.localPosition.z);

        if (isFadeIn)
        {
            TimeTic -= Time.deltaTime;
            FadeColor = FadePanel.color;
            FadeColor.a = TimeTic / FadeTime;
            FadePanel.color = FadeColor;
            if (TimeTic < 0)
            {
                isFadeIn = false;
                TimeTic = 1.0f;
                FadePanel.gameObject.SetActive(false);
            }
        }

        if (isFadeOut)
        {
            TimeTic -= Time.deltaTime;
            FadeColor = FadePanel.color;
            FadeColor.a = (FadeTime - TimeTic) / FadeTime;
            FadePanel.color = FadeColor;

            if (TimeTic < 0)
                if (isStartBtn)
                    SceneManager.LoadScene("GameScene");
                else
                    SceneManager.LoadScene("Title");
        }

        if (0.0f < DelayGetLB)
        {
            DelayGetLB -= Time.deltaTime;
            if (DelayGetLB <= 0.0f)
            {
                GetLeaderboard();
            }
        }

        //<---자동 리셋인 경우
        RestoreTimer -= Time.deltaTime;
        if (RestoreTimer <= 0.0f)
        {
            GetLeaderboard();
            RestoreTimer = 7.0f;  //주기
        }
        //<---자동 리셋인 경우
    }//void Update()

    void RefreshMyInfo()    //<---User 정보 UI 표시 갱신 함수
    {
        MyCoin_Txt.text = "My Coin $" + GlobalValue.g_BestCoin + " " + GlobalValue.g_NickName;
    }

    void RestoreRank()      //<---랭킹 수동 갱신 요청 함수
    {
    }

    public void GetLeaderboard()  //<---랭킹 리스트 불러 오기 함수
    {
        var request = new GetLeaderboardRequest
        {
            StartPosition = 0,
            StatisticName = "BestCoin",
            MaxResultsCount = 10,
            ProfileConstraints = new PlayerProfileViewConstraints()
            {
                ShowDisplayName = true
            }
        };

        PlayFabClientAPI.GetLeaderboard(request,
            (result) =>
            {
                Ranking_Text.text = "";

                for (int i = 0; i < result.Leaderboard.Count; i++)
                {
                    var curBoard = result.Leaderboard[i];

                    if (curBoard.PlayFabId == GlobalValue.g_Unique_ID)//등수 안에 내가 있다면 색 표시
                        Ranking_Text.text += "<color=#ff0000>";

                    Ranking_Text.text += (i + 1).ToString() + "등  $" +
                    curBoard.StatValue + "   " +
                    curBoard.DisplayName + "\n\n";

                    if (curBoard.PlayFabId == GlobalValue.g_Unique_ID)
                        Ranking_Text.text += "</color>";

                    //Debug.Log(curBoard.PlayFabId); //리더보드에서 친구의 ID는 그냥 알 수 있다.
                }

                // GetMyRanking(); //리더보드 등수를 불러온 직 후 내 등수를 불러 온다.
            },
            (error) => Debug.Log("리더보드 불러오기 실패")
        );

    }//public void GetLeaderboard() 



    void UpdateDataCo() //BestScore 갱신 부분
    {
        if (GlobalValue.g_Unique_ID == "")
        {
            return;            //로그인 실패 상태라면 그냥 리턴
        }

        PlayFabClientAPI.UpdatePlayerStatistics(new UpdatePlayerStatisticsRequest
        {
            Statistics = new List<StatisticUpdate>
                    {
                        new StatisticUpdate {StatisticName = "BestCoin",
                                            Value = GlobalValue.g_BestCoin}
                    }
        },

        (result) =>
        {
            Debug.Log("값 저장됨");
        },

        (error) =>
        {
            Debug.Log("값 저장 실패");
        });
    }//void UpdateDataCo()

}
