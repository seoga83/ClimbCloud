﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using PlayFab;
using PlayFab.ClientModels;

public class GameDirector : MonoBehaviour
{
    public Image FadePanel;
    Color FadeColor;
    bool isFadeIn = true;
    bool isFadeOut = false;
    float FadeTime = 1.0f;
    float TimeTic;

    public static int userCoin = 0;

    public Image gdw_Img;
    public Text userCoin_Text;
    public Text gdw_Text;

    public GameObject[] heart_Img;
    [HideInInspector] public int heartCount = 3;

    public GameObject gameOver_Panel;
    public Button replay_Btn;
    public Text gameOver_Text;

    public GameObject gdwPrefab;
    GameObject gdwGo;

    public static bool isGameOver = false;
    public static bool isGdwMode = false;

    // Start is called before the first frame update
    void Start()
    {
        TimeTic = FadeTime;

        userCoin = 0;
        heartCount = 3;
        userCoin_Text.text = "x " + userCoin;

        isGameOver = false;

        if (replay_Btn != null)
            replay_Btn.onClick.AddListener(() =>
            {
                if (GlobalValue.g_BestCoin < userCoin)
                {
                    GlobalValue.g_BestCoin = userCoin;
                    UpdateDataCo();
                }

                SceneManager.LoadScene("Lobby");
            });
    }

    // Update is called once per frame
    void Update()
    {
        if (isFadeIn)
        {
            TimeTic -= Time.deltaTime;
            FadeColor = FadePanel.color;
            FadeColor.a = TimeTic / FadeTime;
            FadePanel.color = FadeColor;
            if (TimeTic < 0)
            {
                isFadeIn = false;
                TimeTic = 1.0f;
                FadePanel.gameObject.SetActive(false);
            }
        }

        gdw_Text.text = (int)(gdw_Img.fillAmount * 100) + " %";

        if(heartCount <= 0)
        {
            isGameOver = true;

            if(gdwPrefab.gameObject != null)
                Destroy(gdwGo);

            gameOver_Panel.gameObject.SetActive(true);
        }

        if(gdw_Img.fillAmount >= 1.0f)
        {
            isGdwMode = true;

            GameObject.FindObjectOfType<PlayerController>().gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
            GameObject.FindObjectOfType<PlayerController>().gameObject.GetComponent<Rigidbody2D>().gravityScale = 0;
            GameObject.FindObjectOfType<PlayerController>().gameObject.GetComponent<BoxCollider2D>().isTrigger = true;
            GameObject.FindObjectOfType<PlayerController>().gameObject.GetComponent<CircleCollider2D>().isTrigger = true;

            if (gdwGo == null)
            {
                gdwGo = Instantiate(gdwPrefab) as GameObject;
                gdwGo.transform.position = GameObject.FindObjectOfType<PlayerController>().gameObject.transform.position;                
                gdwGo.transform.localScale = new Vector3(GameObject.FindObjectOfType<PlayerController>().keyDir * -0.5f, 0.5f, 1);
            }
        }

        if(isGdwMode)
        {
            gdw_Img.fillAmount -= Time.deltaTime * 0.1f;

            if(gdw_Img.fillAmount <= 0)
            {
                Destroy(gdwGo);

                isGdwMode = false;

                gdw_Img.fillAmount = 0;

                if (GameObject.FindObjectOfType<PlayerController>() != null)
                {
                    GameObject.FindObjectOfType<PlayerController>().gameObject.GetComponent<Rigidbody2D>().gravityScale = 3;
                    GameObject.FindObjectOfType<PlayerController>().gameObject.GetComponent<BoxCollider2D>().isTrigger = false;
                    GameObject.FindObjectOfType<PlayerController>().gameObject.GetComponent<CircleCollider2D>().isTrigger = false;
                }
            }
        }
    }

    void UpdateDataCo() //BestScore 갱신 부분
    {
        if (GlobalValue.g_Unique_ID == "")
        {
            return;            //로그인 실패 상태라면 그냥 리턴
        }

        PlayFabClientAPI.UpdatePlayerStatistics(new UpdatePlayerStatisticsRequest
        {
            Statistics = new List<StatisticUpdate>
                    {
                        new StatisticUpdate {StatisticName = "BestCoin",
                                            Value = GlobalValue.g_BestCoin}
                    }
        },

        (result) =>
        {
            Debug.Log("값 저장됨");
        },

        (error) =>
        {
            Debug.Log("값 저장 실패");
        });
    }//void UpdateDataCo()
}
