﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public GameObject coinPrefab;
    public GameObject potionPrefab;

    GameDirector gameDirector;

    public GameObject bombPrefab;

    BoxCollider2D boxCollider2D;
    CircleCollider2D circleCollider2D;
    Rigidbody2D rigid2D;
    Animator animator;
    float jumpForce = 680.0f;
    float walkForce = 30.0f;
    float maxWalkSpeed = 2.5f;
    float colForce = 220.0f;

    [HideInInspector] public int keyDir = 1;

    // Start is called before the first frame update
    void Start()
    {
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 60;

        gameDirector = GameObject.FindObjectOfType<GameDirector>();

        boxCollider2D = GetComponent<BoxCollider2D>();
        circleCollider2D = GetComponent<CircleCollider2D>();
        rigid2D = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (GameDirector.isGameOver)
        {
            gameObject.SetActive(false);
            return;
        }

        if (gameDirector.gdw_Img.fillAmount >= 1.0f)
        {
            GameDirector.isGdwMode = true;
        }

        if (Input.GetKeyDown(KeyCode.UpArrow) && rigid2D.velocity.y == 0 && !GameDirector.isGdwMode)
        {
            animator.SetTrigger("JumpTrigger");
            rigid2D.AddForce(transform.up * jumpForce);
        }

        int key = 0;
        if (Input.GetKey(KeyCode.RightArrow) && !GameDirector.isGdwMode)
        {
            animator.SetTrigger("WalkTrigger");
            key = 1;
            keyDir = key;
        }
        if (Input.GetKey(KeyCode.LeftArrow) && !GameDirector.isGdwMode)
        {
            animator.SetTrigger("WalkTrigger");
            key = -1;
            keyDir = key;
        }

        if (Mathf.Abs(rigid2D.velocity.x) == 0 && Mathf.Abs(rigid2D.velocity.y) == 0)
            animator.SetTrigger("StandTrigger");

        if (Input.GetKeyDown(KeyCode.Space))
        {
            GameObject go = Instantiate(bombPrefab) as GameObject;
            go.GetComponent<BombController>().xDir = keyDir;

            go.transform.position = transform.position + new Vector3(0, 0.5f, 0);
        }

        float speedx = Mathf.Abs(rigid2D.velocity.x);

        if (speedx < maxWalkSpeed)
        {
            rigid2D.AddForce(transform.right * key * walkForce);
        }
        else if (rigid2D.velocity.x * key < 0)
        {
            rigid2D.AddForce(transform.right * key * walkForce);
        }

        if (key != 0)
        {
            transform.localScale = new Vector3(key, 1, 1);
        }

        if (rigid2D.velocity.y == 0)
        {
            animator.speed = speedx / 2.0f;
        }
        else
        {
            animator.speed = 1.0f;
        }

        if (!GameDirector.isGdwMode)
        {
            if (rigid2D.velocity.y > 0.1f)
            {
                circleCollider2D.isTrigger = true;
                boxCollider2D.isTrigger = true;
            }
            else
            {
                circleCollider2D.isTrigger = false;
                boxCollider2D.isTrigger = false;
            }
        }

        if (transform.position.y < -10)
        {
            gameDirector.heartCount = 0;
        }

        if (transform.position.x < -3.0f)
            transform.position = new Vector3(-transform.position.x - 0.1f, transform.position.y, transform.position.z);
        else if (transform.position.x > 3.0f)
            transform.position = new Vector3(-transform.position.x + 0.1f, transform.position.y, transform.position.z);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject == GameObject.Find("flag"))
        {
            SceneManager.LoadScene("ClearScene");
        }

        if (other.gameObject.tag == "Monster")
        {
            gameDirector.heart_Img[--gameDirector.heartCount].SetActive(false);

            Vector3 dir = gameObject.transform.position - other.gameObject.transform.position;
            dir = dir.normalized;

            Vector2 dir2 = new Vector2(dir.x * colForce * 2, dir.y * colForce * 2);
            GdwController gdwController = GameObject.FindObjectOfType<GdwController>();
            if (gdwController != null)
                gdwController.rigid2D.AddForce(dir2);
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject == GameObject.Find("Zombi1"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi1isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi1(Clone)"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi1isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi2"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi2isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi2(Clone)"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi2isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi3"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi3isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi3(Clone)"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi3isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi4"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi4isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi4(Clone)"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi4isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi6"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi6isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi6(Clone)"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi6isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi8"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi8isActive = false;
        }

        if (other.gameObject == GameObject.Find("Zombi8(Clone)"))
        {
            colPlayerMonster(other);

            GameObject.FindObjectOfType<MonsterMgr>().zombi8isActive = false;
        }
    }

    private void colPlayerMonster(Collision2D other)
    {
        if (gameObject.transform.position.y - other.gameObject.transform.position.y > 0.43f)
        {
            Vector3 dir = gameObject.transform.position - other.gameObject.transform.position;
            dir = dir.normalized;
            Vector2 dir2 = new Vector2(dir.x * colForce, dir.y * colForce);
            rigid2D.AddForce(dir2);

            Destroy(other.gameObject);

            //gameDirector.gdw_Img.fillAmount += 0.2f;

            if (Random.Range(1, 11) >= 4)
            {
                Instantiate(coinPrefab).transform.position = other.gameObject.transform.position;
            }
            else
            {
                Instantiate(potionPrefab).transform.position = other.gameObject.transform.position;
            }
        }
        else
        {
            Vector3 dir = gameObject.transform.position - other.gameObject.transform.position;
            dir = dir.normalized;

            Vector2 dir2 = new Vector2(dir.x * colForce, dir.y * colForce);
            rigid2D.AddForce(dir2);

            gameDirector.heart_Img[--gameDirector.heartCount].SetActive(false);
        }
    }
}
